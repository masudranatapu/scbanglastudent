<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
<link rel="stylesheet" href="{{asset('public/frontend/css/plugin.css')}}" />
<link rel="stylesheet" href="{{asset('public/frontend/css/style.css')}}" />
<link rel="stylesheet" href="{{asset('public/frontend/css/responsive.css')}}" />
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
<!-- Latest compiled and minified CSS -->
