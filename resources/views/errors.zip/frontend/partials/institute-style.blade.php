<link rel="stylesheet" href="{{asset('public/frontend/institute')}}/css/bootstrap.min.css">
<link rel="stylesheet" href="{{asset('public/frontend/institute')}}/css/owl.carousel.min.css">
<link rel="stylesheet" href="{{asset('public/frontend/institute')}}/css/owl.theme.default.min.css">
<link rel="stylesheet" href="{{asset('public/frontend/institute')}}/css/flaticon.css">
<link rel="stylesheet" href="{{asset('public/frontend/institute')}}/css/style.css">