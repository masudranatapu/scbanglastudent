<script type="text/javascript" src="{{asset('public/frontend/js/plugin.js')}}"></script>
<script type="text/javascript" src="{{asset('public/frontend/js/script.js')}}"></script>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
<!-- Latest compiled and minified JavaScript -->
<script>
    $(document).ready(function() {
        $('#summernote').summernote({
            height: 500,
        });
    });
</script>