<script src="{{asset('public/frontend/institute')}}/js/jquery.min.js"></script>
<script src="{{asset('public/frontend/institute')}}/js/bootstrap.min.js"></script>
<script src="{{asset('public/frontend/institute')}}/js/owl.carousel.min.js"></script>
<script src="{{asset('public/frontend/institute')}}/js/main.js"></script>