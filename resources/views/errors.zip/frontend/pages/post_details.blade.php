@extends('frontend.master')

@section('content')
<link rel="stylesheet" href="{{asset('public/frontend/css/post-style.css')}}" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<div class="bg-white border-bottom my-4"> 
    <div class="container"> 
        <div class="page-header"> 
            <h4 class="page-title">Post</h4> 
            <ol class="breadcrumb"> 
                <li class="breadcrumb-item"><a href="#">Home</a></li> 
                <li class="breadcrumb-item"><a href="#">Post</a></li> 
                <li class="breadcrumb-item active" aria-current="page">{{$post->post_title ?? ''}}</li> 
            </ol> 
        </div> 
    </div> 
</div>

<div class="container">
    <div class="row">
        <div class="col-xl-8 col-lg-8 col-md-12">
            <!--Classified Description-->
            <div class="card overflow-hidden">
                <!-- <div class="ribbon ribbon-top-right text-danger"><span class="bg-danger">
                    {{$post->monthly_tuition_fee ?? ''}} ৳</span>
                </div> -->
                <div class="card-body h-100">
                    <div class="item-det mb-4">
                        <a href="#" class="text-dark"><h2>
                            <b>{{$post->post_title ?? ''}}</b>
                        </h2></a>
                        <div class="d-flex">
                            
                        </div>
                    </div>
                    <div class="product-slider">
                        <img src="{{ asset('public/uploads/'.$post->post_thumbnail) }}" alt="">
                    </div>
                </div>
            </div>
            <div class="mb-4">
                <div class="row">
                    <div class="col-md-3">
                       <div class="p-3" style="background-color:#4472C4; color:#fff;">
                            <h5 class="m-0">Tuition Fee 
                                @if($post->offer_fee)
                                    {{ $post->offer_fee ?? '' }} ৳
                                @else
                                    {{ $post->monthly_tuition_fee ?? '' }} ৳
                                @endif

                            </h5>
                       </div>
                    </div>
                    <div class="col-md-5">
                        <div class="p-3" style="background-color:#4472C4; color:#fff;">
                            <h5 class="m-0">Apply Last Date: {{ \Carbon\Carbon::parse($post->apply_before)->diffForHumans() ?? '' }}</h5>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="p-3" style="background-color:#4472C4; color:#fff;">
                                <h5 class="m-0">Phone: {{$post->institute->phone ?? ''}}</h5>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header"><h3 class="card-title">Description</h3></div>
                <div class="card-body">
                    <div class="mb-4">
                        {!! $post->description ?? '' !!}
                    </div>
                </div>
            </div>
            <!--/Classified Description-->
<!--             <h3 class="mb-5 mt-4">Related Posts</h3> -->
            <!--Related Posts-->
 {{--           <div id="myCarousel5" class="owl-carousel owl-carousel-icons3 owl-loaded owl-drag">
                <!-- Wrapper for carousel items -->
                <div class="owl-stage-outer">
                    <div class="owl-stage" style="transform: translate3d(-1602px, 0px, 0px); transition: all 0.25s ease 0s; width: 6408px;">
                        <div class="owl-item cloned" style="width: 375.5px; margin-right: 25px;">
                            <div class="item">
                                <div class="card">
                                    <div class="item-card7-img">
                                        <div class="item-card7-imgs"><a href="classified.html"></a> <img src="../assets/images/products/products/pe1.jpg" alt="img" class="cover-image" /></div>
                                        <div class="item-card7-overlaytext">
                                            <a href="classified.html" class="text-white"> Pets &amp; Animals</a>
                                            <h4 class="font-weight-semibold mb-0">$925</h4>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="item-card7-desc">
                                            <a href="classified.html" class="text-dark"><h4 class="font-weight-semibold">Care Brohzm</h4></a>
                                        </div>
                                        <div class="item-card7-text">
                                            <ul class="icon-card mb-0">
                                                <li>
                                                    <a href="#" class="icons"><i class="si si-location-pin text-muted me-1"></i> Los Angles</a>
                                                </li>
                                                <li>
                                                    <a href="#" class="icons"><i class="si si-event text-muted me-1"></i> 5 hours ago</a>
                                                </li>
                                                <li class="mb-0">
                                                    <a href="#" class="icons"><i class="si si-user text-muted me-1"></i> Sally Peake</a>
                                                </li>
                                                <li class="mb-0">
                                                    <a href="#" class="icons"><i class="si si-phone text-muted me-1"></i> 5-67987608</a>
                                                </li>
                                            </ul>
                                            <p class="mb-0">Sed ut perspiciatis unde omnis iste natus error sit voluptatem....</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="owl-nav disabled">
                    <button type="button" role="presentation" class="owl-prev"><span aria-label="Previous">‹</span></button><button type="button" role="presentation" class="owl-next"><span aria-label="Next">›</span></button>
                </div>
                <div class="owl-dots disabled"></div>
            </div> --}}
            <!--/Related Posts-->
        </div>
        <!--Right Side Content-->
        <div class="col-xl-4 col-lg-4 col-md-12">
            <div class="card mb-4">
                <div class="card-header">
                    <h3 class="card-title">Institute Details</h3>
                </div>
                <div class="card-body item-user">
                    <div class="profile-pic mb-0">
                        <img src="{{ asset('public/uploads/'.$post->institute->logo) }}" class="brround avatar-xxl" alt="Institute" />
                        <h4 class="text-dark mt-3 mb-1 font-weight-semibold">Established In : {{ $post->institute->established_in ?? '' }}</h4> 
                        <h4 class="text-dark mt-3 mb-1 font-weight-semibold">Location : {{ $post->institute->location ?? '' }}</h4>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Post Details</h3>
                </div>
                    <div class="card-body item-user">
                        <div class="billing-content">
                            <li class="d-flex align-items-center"><p> <span class="color-text-2 font-weight-medium mr-1">Institute Name : </span> 
                                <a href="http://localhost/sc/institute/details/1">{{$post->institute->institute_name ?? ''}}</a> </p>
                            </li>
                            <li class="d-flex align-items-center"><p> <span class="color-text-2 font-weight-medium mr-1">Institute Type : {{ $post->institute->institute_type->institute_type ?? '' }} </span></p></li>
                            <li class="d-flex align-items-center"><p> <span class="color-text-2 font-weight-medium mr-1">Monthly Tuition Fee : </span>@if($post->offer_fee) {{ $post->offer_fee ?? '' }}@else {{ $post->monthly_tuition_fee ?? '' }}@endif ৳</p></li>
                            <li class="d-flex align-items-center"><p><span class="color-text-2 font-weight-medium mr-1">Class : {{$post->class->class_name ?? ''}}</span></p> </li>
                            <li class="d-flex align-items-center"><p> <span class="color-text-2 font-weight-medium mr-1">Group :</span> {{$post->group->group_name ?? ''}}</p></li>
                            <li class="d-flex align-items-center"><p> <span class="color-text-2 font-weight-medium mr-1">Shift :</span> {{$post->shift->name ?? ''}}</p></li>
                            <li class="d-flex align-items-center"><p><span class="color-text-2 font-weight-medium mr-1">Gender :</span> {{$post->gender ?? ''}}</p></li>
                            <li class="d-flex align-items-center"><p><span class="color-text-2 font-weight-medium mr-1">Maximum Seat :</span> {{$post->maximum_seat ?? ''}}</p></li>
                            <li class="d-flex align-items-center"><p> <span class="color-text-2 font-weight-medium mr-1">Apply Before : {{ \Carbon\Carbon::parse($post->apply_before)->diffForHumans() ?? '' }} </span> </p></li>
                        </div>
                    </div>
            </div>
        </div>
        <div class="col-xl-12 col-lg-12 col-md-12">
            
            <div class="card-body item-user">
                <h4 class="mb-4">Contact Info</h4>
                <div>
                <h6>
                    <span class="font-weight-semibold"><i class="fa fa-envelope me-3 mb-2"></i></span>
                    <a href="mailto::{{ $post->institute->user->email ?? '' }}" class="text-body"> {{$post->institute->user->email ?? ''}}</a>
                </h6>
                <h6>
                    <span class="font-weight-semibold"><i class="fa fa-phone me-3 mb-2"></i></span>
                    <a href="tel:{{ $post->institute->phone ?? '' }}" class="text-primary">{{$post->institute->phone ?? ''}}</a>
                </h6>
                <h6>
                    <span class="font-weight-semibold">
                        <i class="fa fa-link me-3"></i></span>
                        <a href="{{ $post->institute->website ?? '' }}" class="text-primary">{{ $post->institute->website ?? '' }}</a>
                </h6>
            </div>
            <div class="card">
                <div class="card-header"><h3 class="card-title">Social Media</h3></div>
                <div class="card-body product-filter-desc">
                    <div class="product-filter-icons text-center">
                        <a href="https://www.facebook.com/sharer/sharer.php?u=YourPageLink.com&display=popup" class="facebook-bg"><i class="fa-brands fa-facebook-f"></i></a> 
                        <a href="{{ $post->institute->twitter_link ?? '' }}" class="twitter-bg"><i class="fa-brands fa-twitter"></i></a> 
                        <a href="{{ $post->institute->instagram_link ?? '' }}" class="bg-secondary"><i class="fa-brands text-light fa-instagram"></i></a>
                    </div>
                </div>
            </div>
                </div>
            </div>
        </div>
            </div>
        </div>
        <!--/Right Side Content-->

    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/js/all.min.js" integrity="sha512-6PM0qYu5KExuNcKt5bURAoT6KCThUmHRewN3zUFNaoI6Di7XJPTMoT6K0nsagZKk2OB4L7E3q1uQKHNHd4stIQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
@endsection