@extends('frontend.master')

@section('content')
{{-- <section class="py-4 bg-light">
    <div class="container">
        <div class="d-flex align-items-center justify-content-between gap-4">
            <div class="flex-grow-1">
                <h4 class="h4 fw-600 text-dark mb-0">{{$board->board_name ?? ''}}</h4>
</div>
<div class="custom-breadcrumb">
    <div class="breadcrumbs">
        <a class="text-dark fs-15 fw-500 text-muted" href="{{route('home')}}">হোম</a>
        <span class="mx-2 border-start"></span>
        <span class="text-dark fs-15 fw-500 ps-1">{{$board->board_name ?? ''}}</span>
    </div>
</div>
</div>
</div>
</section> --}}

<section class="py-4 position-relative z-2 text-white bg-no-repeat bg-cover"
    style="background-image: url(https://visathingforstudent.com/wp-content/uploads/2022/05/Western-Caspian-University-campus.jpg)">
    <div class="absolute-full z--1 bg-dark opacity-90"></div>
    <div class="container">
        <div class="row clearfix">
            <div class="col-12">
                <div class="">
                    <div class="university-title">
                        <div class="d-flex gap-4 align-items-center flex-md-nowrap flex-wrap justify-content-center">
                            <div class="flex-shrink-0">
                                <span class="factorylogo">
                                    <img class="lazyload img-contain bg-white rounded" width="160" height="160"
                                        data-src="https://visathingforstudent.com/wp-content/uploads/2022/05/Caspian-logo-1.jpg"
                                        alt="Logo">
                                </span>
                            </div>
                            <div class="flex-grow-1">
                                <h2 class="h2 mb-3 fw-600">{{$board->board_name ?? ''}}</h2>
                                <ul class="list-unstyled mb-0 row gy-2 fs-16">
                                    <li class="col-12">
                                        <i class="fa-solid fa-location-dot me-2"></i> 31, Istiglaliyyat Street, Baku,
                                        Azerbaijan,
                                        AZ1001 </li>


                                    <li class="col-12">
                                        <a href="#" target="_blank" class=""><i class="fa fa-globe me-2"></i> Visit
                                            University Websites </a>
                                    </li>
                                    <li class="col-12">
                                        <i class="fa fa-file-text me-2"></i> University Type: Private University </li>
                                    <li class="col-12">
                                        <i class="fa fa-thumbs-up me-2"></i> Famous For : Excellence in education/
                                        Quality Education </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12">
                <div class="pt-3 mt-3 border-top border-light"></div>
                <ul class="row list-unstyled mb-0 g-3">
                    <li class="col-lg-3 col-sm-6">
                        <div
                            class="d-flex align-items-center gap-3 fs-16 fw-600 border border-light rounded-3 p-2 px-3 bg-primary">
                            <svg class="flex-shrink-0" xmlns="http://www.w3.org/2000/svg" height="34"
                                fill="currentColor" class="bi bi-mortarboard-fill" viewBox="0 0 16 16">
                                <path
                                    d="M8.211 2.047a.5.5 0 0 0-.422 0l-7.5 3.5a.5.5 0 0 0 .025.917l7.5 3a.5.5 0 0 0 .372 0L14 7.14V13a1 1 0 0 0-1 1v2h3v-2a1 1 0 0 0-1-1V6.739l.686-.275a.5.5 0 0 0 .025-.917l-7.5-3.5Z" />
                                <path
                                    d="M4.176 9.032a.5.5 0 0 0-.656.327l-.5 1.7a.5.5 0 0 0 .294.605l4.5 1.8a.5.5 0 0 0 .372 0l4.5-1.8a.5.5 0 0 0 .294-.605l-.5-1.7a.5.5 0 0 0-.656-.327L8 10.466 4.176 9.032Z" />
                            </svg>
                            <div class="flex-grow-1">Total<br>Students</div>
                            <span class="flex-shrink-0 border-start border-light ps-3">4000</span>
                        </div>
                    </li>
                    <li class="col-lg-3 col-sm-6">
                        <div
                            class="d-flex align-items-center gap-3 fs-16 fw-600 border border-light rounded-3 p-2 px-3 bg-primary">
                            <svg class="flex-shrink-0" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"
                                height="34" fill="currentColor">
                                <path
                                    d="M512 32H64C28.65 32 0 60.65 0 96v320c0 35.35 28.65 64 64 64h448c35.35 0 64-28.65 64-64V96C576 60.65 547.3 32 512 32zM176 128c35.35 0 64 28.65 64 64s-28.65 64-64 64s-64-28.65-64-64S140.7 128 176 128zM272 384h-192C71.16 384 64 376.8 64 368C64 323.8 99.82 288 144 288h64c44.18 0 80 35.82 80 80C288 376.8 280.8 384 272 384zM496 320h-128C359.2 320 352 312.8 352 304S359.2 288 368 288h128C504.8 288 512 295.2 512 304S504.8 320 496 320zM496 256h-128C359.2 256 352 248.8 352 240S359.2 224 368 224h128C504.8 224 512 231.2 512 240S504.8 256 496 256zM496 192h-128C359.2 192 352 184.8 352 176S359.2 160 368 160h128C504.8 160 512 167.2 512 176S504.8 192 496 192z" />
                            </svg>
                            <div class="flex-grow-1">International<br>Students</div>
                            <span class="flex-shrink-0 border-start border-light ps-3">200</span>
                        </div>
                    </li>

                    <li class="col-lg-3 col-sm-6">
                        <div
                            class="d-flex align-items-center gap-3 fs-16 fw-600 border border-light rounded-3 p-2 px-3 bg-primary">
                            <svg class="flex-shrink-0" xmlns="http://www.w3.org/2000/svg" height="34"
                                fill="currentColor" class="bi bi-building" viewBox="0 0 16 16">
                                <path fill-rule="evenodd"
                                    d="M14.763.075A.5.5 0 0 1 15 .5v15a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5V14h-1v1.5a.5.5 0 0 1-.5.5h-9a.5.5 0 0 1-.5-.5V10a.5.5 0 0 1 .342-.474L6 7.64V4.5a.5.5 0 0 1 .276-.447l8-4a.5.5 0 0 1 .487.022zM6 8.694 1 10.36V15h5V8.694zM7 15h2v-1.5a.5.5 0 0 1 .5-.5h2a.5.5 0 0 1 .5.5V15h2V1.309l-7 3.5V15z" />
                                <path
                                    d="M2 11h1v1H2v-1zm2 0h1v1H4v-1zm-2 2h1v1H2v-1zm2 0h1v1H4v-1zm4-4h1v1H8V9zm2 0h1v1h-1V9zm-2 2h1v1H8v-1zm2 0h1v1h-1v-1zm2-2h1v1h-1V9zm0 2h1v1h-1v-1zM8 7h1v1H8V7zm2 0h1v1h-1V7zm2 0h1v1h-1V7zM8 5h1v1H8V5zm2 0h1v1h-1V5zm2 0h1v1h-1V5zm0-2h1v1h-1V3z" />
                            </svg>
                            <div class="flex-grow-1"> University<br> Ranked</div>
                            <span class="flex-shrink-0 border-start border-light ps-3">601</span>
                        </div>
                    </li>

                    <li class="col-lg-3 col-sm-6">
                        <div
                            class="d-flex align-items-center gap-3 fs-16 fw-600 border border-light rounded-3 p-2 px-3 bg-primary">
                            <svg class="flex-shrink-0" xmlns="http://www.w3.org/2000/svg" height="34"
                                fill="currentColor" class="bi bi-calendar3" viewBox="0 0 16 16">
                                <path
                                    d="M14 0H2a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zM1 3.857C1 3.384 1.448 3 2 3h12c.552 0 1 .384 1 .857v10.286c0 .473-.448.857-1 .857H2c-.552 0-1-.384-1-.857V3.857z" />
                                <path
                                    d="M6.5 7a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm-9 3a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm-9 3a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2z" />
                            </svg>
                            <div class="flex-grow-1">Established <br> year</div>
                            <span class="flex-shrink-0 border-start border-light ps-3">1991</span>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>

<section class="py-3">
    <div class="container">
        <div class="row g-4">
            <div class="col-xl-9 col-lg-8">
                <!--Classified Description-->
                <div class="card">
                    <div class="ribbon ribbon-top-right text-white"><span
                            class="bg-primary px-10px">{{$board->division->division_name ?? ''}}</span></div>
                    <div class="card-body h-100">
                        <div class="item-det">
                            <h3 class="fw-600 mb-md-3 mb-2 text-lg-start text-center">{{$board->board_name ?? ''}}</h3>
                        </div>
                        <div class="carousel mb-3" data-items="1" data-fade="true" data-autoplay="true" data-infinite="true">
                            <div class="single-item">
                                <img class="lazyload w-100 img-fit responsive-slide-img"
                                    data-src="https://visathingforstudent.com/wp-content/uploads/2022/05/Western-Caspian-University-campus.jpg"
                                    height="400" alt="Slide Image">
                            </div>
                            <div class="single-item">
                                <img class="lazyload w-100 img-fit responsive-slide-img"
                                    data-src="https://images.unsplash.com/20/cambridge.JPG?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=847&q=80 847w, https://images.unsplash.com/20/cambridge.JPG?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1147&q=80 1147w, https://images.unsplash.com/20/cambridge.JPG?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1447&q=80 1447w, https://images.unsplash.com/20/cambridge.JPG?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1694&q=80 1694w, https://images.unsplash.com/20/cambridge.JPG?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1747&q=80 1747w, https://images.unsplash.com/20/cambridge.JPG?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2047&q=80 2047w, https://images.unsplash.com/20/cambridge.JPG?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2294&q=80 2294w, https://images.unsplash.com/20/cambridge.JPG?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2347&q=80 2347w, https://images.unsplash.com/20/cambridge.JPG?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2647&q=80 2647w, https://images.unsplash.com/20/cambridge.JPG?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2894&q=80 2894w, https://images.unsplash.com/20/cambridge.JPG?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2947&q=80 2947w, https://images.unsplash.com/20/cambridge.JPG?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=3247&q=80 3247w, https://images.unsplash.com/20/cambridge.JPG?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=3494&q=80 3494w, https://images.unsplash.com/20/cambridge.JPG?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=3547&q=80 3547w, https://images.unsplash.com/20/cambridge.JPG?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=3578&q=80 3578w"
                                    height="400" alt="Slide Image">
                            </div>
                            <div class="single-item">
                                <img class="lazyload w-100 img-fit responsive-slide-img"
                                    data-src="https://visathingforstudent.com/wp-content/uploads/2022/05/Western-Caspian-University-campus.jpg"
                                    height="400" alt="Slide Image">
                            </div>
                        </div>
                        <div class="mb-4 fs-15">
                            {!! $board->description ?? '' !!}
                        </div>
                    </div>
                </div>

            </div>
            <!--Right Side Content-->
            <div class="col-xl-3 col-lg-4">
                <div class="card">
                    <div class="card-header">
                        <h4 class="h4 fw-600 card-title mb-0">Board Details</h4>
                    </div>
                    <div class="card-body item-user">
                        <div class="text-center">
                            <h5 class="h5">{{$board->board_name ?? ''}}</h5>
                        </div>
                        <div class="profile-pic mb-0">
                            <div class="text-center">
                                <img class="lazyload img-contain mw-200px w-100"
                                    data-src="{{ asset('public/uploads/'.$board->logo) }}" class="brround avatar-xxl"
                                    alt="Board" />
                            </div>
                            @if($board->established_in)
                            <h4 class="h6 text-dark mt-2 mb-1 font-weight-semibold">Established In :
                                {{ $board->established_in ?? '' }}</h4>
                            @endif
                            @if($board->location)
                            <h4 class="h6 text-dark mt-2 mb-1 font-weight-semibold">Location :
                                {{ $board->location ?? '' }}
                            </h4>
                            @endif
                        </div>
                    </div>
                    <div class="card-body border-top">
                        <h5 class="h5 mb-3">Contact Info</h5>
                        <div class="row gy-2">
                            <div class="col-12">
                                <span class="font-weight-semibold"><i class="fa fa-envelope me-2"></i></span>
                                <a href="mailto::{{ $board->email ?? '' }}" class="text-body">
                                    {{$board->email ?? ''}}</a>
                            </div>
                            <div class="col-12">
                                <span class="font-weight-semibold"><i class="fa fa-phone me-2"></i></span>
                                <a href="tel:{{ $board->phone ?? '' }}" class="text-primary">{{$board->phone ?? ''}}</a>
                            </div>
                            <div class="col-12">
                                <span class="font-weight-semibold">
                                    <i class="fa fa-link me-2"></i></span>
                                <a href="https://{{$board->website ?? ''}}"
                                    class="text-primary">{{ $board->website ?? '' }}</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card mt-4">
                    <div class="card-header">
                        <h3 class="h4 mb-0 fw-600">Social Media</h3>
                    </div>
                    <div class="card-body product-filter-desc">
                        <div class="d-flex align-items-center gap-3 justify-content-center">
                            <a href="{{$board->facebook_link ?? ''}}" class="">
                                <i class="fa-brands fa-facebook-f fs-24"></i>
                            </a>
                            <a href="{{ $board->twitter_link ?? '' }}" class="">
                                <i class="fa-brands fa-twitter fs-24"></i>
                            </a>
                            <a href="{{ $board->instgram_link ?? '' }}" class="">
                                <i class="fa-brands fa-linkedin-in fs-24"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <!--/Right Side Content-->
        </div>
    </div>
</section>

<section class="py-4">
    <div class="container">
        <div class="pe-4">
            <h4 class="mb-3 fw-600 h4 custom-title">List of Institutions of Dhaka Education Board</h4>
        </div>
        <div class="row g-3">
            @if( count($institutes) > 0 )
            @foreach($institutes as $institute)
            <div class="col-xl-3 col-lg-4 col-md-6">
                <div class="single-post p-3 h-100">
                    <div class="absolute-top-right">
                        <div class="featured">
                            <i class="fa-solid fa-bolt-lightning"></i>
                        </div>
                    </div>
                    <div class="d-flex flex-column justify-content-between h-100">
                        <div class="item-body">
                            <h6 class="h6 text-truncate-2 mb-3 text-dark"><a
                                    href="{{ route('institute_details',$institute->institute_slug) }}">{{$institute->institute_name ?? ''}}</a>
                            </h6>
                            <div class="d-flex gap-3 mb-3">
                                <figure class="mb-0 flex-shrink-0">
                                    <img class="lazyload img-contain shadow-custom rounded-2" width="70" height="70"
                                        data-src="{{asset('public/uploads/'.$institute->logo)}}">
                                </figure>
                                <ul class="list-unstyled mb-0 row gx-0 gy-2 flex-grow-1 hov-content">
                                    @foreach($institute->post as $post)
                                    <li class="col-12">
                                        <span class="icon">
                                            <i class="fas fa-hand-point-right"></i>
                                        </span>
                                        <a href="{{ route('post_details',$post->post_slug) }}">
                                            <span style="font-size: 14px;">
                                                {{$post->class->class_name ?? ''  }} -
                                                {{ $institute->sub_institute_type->sub_institute_type ?? '' }}</span>
                                        </a>
                                    </li>
                                    @endforeach
                                </ul>
                            </div>
                        </div>
                        <div class="d-flex align-items-center gap-3">
                            <div class="flex-grow-1">
                                <div class="d-flex align-items-center">
                                    <span class="icon text-primary pe-1 pt-1"><i
                                            class="fa-solid fa-location-arrow fs-18"></i></span>
                                    @if($institute->district)
                                    {{ $institute->district->district_name }}
                                    @else
                                    Bangladesh
                                    @endif
                                </div>
                            </div>
                            <div class="flex-shrink-0">
                                <a href="{{ route('institute_details',$institute->institute_slug) }}"
                                    class="detail underline">আরো
                                    দেখুন</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
            @endif
        </div>
    </div>
</section>
@endsection
