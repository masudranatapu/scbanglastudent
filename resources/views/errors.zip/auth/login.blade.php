@extends('frontend.master')
@section('content')

<section class="py-5">
    <div class="container">
        <div
            class="mw-400px w-100 mx-auto p-4 shadow-md rounded-10px has-blur overflow-hidden border-2 border border-white position-relative">
            <div id="CustomerLoginForm">
                <h4
                    class="h4 mb-3 text-dark fw-600 d-flex align-items-center gap-2 border-bottom border-2 pb-3 justify-content-center">
                    <span class="flex-shrink-0 size-40px text-primary place-items-center rounded-circle"
                        style="background-color: rgb(240 136 49 / 20%);">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                            class="bi bi-key-fill" viewBox="0 0 16 16">
                            <path
                                d="M3.5 11.5a3.5 3.5 0 1 1 3.163-5H14L15.5 8 14 9.5l-1-1-1 1-1-1-1 1-1-1-1 1H6.663a3.5 3.5 0 0 1-3.163 2zM2.5 9a1 1 0 1 0 0-2 1 1 0 0 0 0 2z" />
                        </svg>
                    </span>
                    <span class="flex-shrink-0">Log in</span>
                </h4>
                <form method="post" action="#">
                    <div class="row gy-2 gx-0">
                        <div class="col-12">
                            <label for="exampleInputEmail1" class="form-label text-muted">Email address</label>
                            <input type="email" class="form-control rounded-10px border-2" id="exampleInputEmail1"
                                aria-describedby="emailHelp">
                            <div id="emailHelp" class="form-text">We'll never share your email with anyone else.
                            </div>
                        </div>
                        <div class="col-12">
                            <label for="exampleInputPassword1" class="form-label text-muted">Password</label>
                            <input type="password" class="form-control rounded-10px border-2"
                                id="exampleInputPassword1">
                        </div>
                        <div class="col-7 pt-2">
                            <a href="#" onclick="showRecoverPasswordForm();return false;">Forgot
                                your password?</a>
                        </div>
                        <div class="col-5 pt-2 text-end">
                            <a href="#" onclick="ShowCreateAccountForm();return false;">Create account</a>
                        </div>
                        <div class="col-12">
                            <div class="d-grid pt-3">
                                <button type="submit" class="btn bg-primary text-white rounded-10px">Submit</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div id="RecoverPasswordForm" style="display: none;">
                <h4
                    class="h4 mb-3 text-dark fw-600 d-flex align-items-center gap-2 border-bottom border-2 pb-3 justify-content-center">
                    <span class="flex-shrink-0 size-40px text-primary place-items-center rounded-circle"
                        style="background-color: rgb(240 136 49 / 20%);">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                            class="bi bi-key-fill" viewBox="0 0 16 16">
                            <path
                                d="M3.5 11.5a3.5 3.5 0 1 1 3.163-5H14L15.5 8 14 9.5l-1-1-1 1-1-1-1 1-1-1-1 1H6.663a3.5 3.5 0 0 1-3.163 2zM2.5 9a1 1 0 1 0 0-2 1 1 0 0 0 0 2z" />
                        </svg>
                    </span>
                    <span class="flex-shrink-0">Reset your password</span>
                </h4>
                <form method="post" action="#">
                    <div class="row gy-2 gx-0">
                        <div class="col-12">
                            <label for="exampleInputEmail1" class="form-label text-muted">Email address</label>
                            <input type="email" class="form-control rounded-10px border-2" id="exampleInputEmail1"
                                aria-describedby="emailHelp">
                            <div id="emailHelp" class="form-text">We will send you an email to reset your password.
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="d-grid pt-3">
                                <button type="submit" class="btn bg-primary text-white rounded-10px">Submit</button>
                            </div>
                        </div>
                        <div class="col-12 text-center">
                            <div class="py-3 fs-16 fw-500">Or</div>
                            <a class="btn bg-secondary text-white lh-1 px-4" href="#"
                                onclick="hideRecoverPasswordForm();return false;">Login</a>
                        </div>
                    </div>
                </form>
            </div>
            <div id="CreateAccountForm" style="display: none;">
                <h4
                    class="h4 mb-3 text-dark fw-600 d-flex align-items-center gap-2 border-bottom border-2 pb-3 justify-content-center">
                    <span class="flex-shrink-0 size-40px text-primary place-items-center rounded-circle"
                        style="background-color: rgb(240 136 49 / 20%);">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                            class="bi bi-key-fill" viewBox="0 0 16 16">
                            <path
                                d="M3.5 11.5a3.5 3.5 0 1 1 3.163-5H14L15.5 8 14 9.5l-1-1-1 1-1-1-1 1-1-1-1 1H6.663a3.5 3.5 0 0 1-3.163 2zM2.5 9a1 1 0 1 0 0-2 1 1 0 0 0 0 2z" />
                        </svg>
                    </span>
                    <span class="flex-shrink-0">Create an account</span>
                </h4>
                <form method="post" action="#">
                    <div class="row gy-2 gx-0">

                        <div class="col-12">
                            <label class="form-label text-muted">Institute Name</label>
                            <input type="text" name="institute_name" class="form-control rounded-10px border-2"
                                placeholder="Enter Institute name ">
                        </div>
                        <div class="col-12">
                            <label class="form-label text-muted">Select Type</label>
                            <select name="institute_type" class="form-select rounded-10px border-2" id="category">
                                <option value="" selected="" disabled="">Select One</option>
                                <option value="School and College">School and College</option>
                                <option value="School">School</option>
                                <option value="College">College</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label text-muted">Select Sub Type</label>
                            <select name="sub_institute_type_id" class="form-select rounded-10px border-2" id="subcategory">
                                <optgroup label="School and College">
                                </optgroup>
                                <!--<option value="8">[]</option>-->
                                <optgroup label="School">
                                    <option value="36">Private School</option>
                                    <option value="38">Govt. School</option>
                                </optgroup>
                                <!--<option value="7">[{&quot;id&quot;:36,&quot;institute_type_id&quot;:7,&quot;sub_institute_type&quot;:&quot;Private School&quot;,&quot;sub_institute_type_slug&quot;:&quot;Private-School&quot;,&quot;created_at&quot;:&quot;2022-06-16T18:30:36.000000Z&quot;,&quot;updated_at&quot;:&quot;2022-06-16T18:33:11.000000Z&quot;},{&quot;id&quot;:38,&quot;institute_type_id&quot;:7,&quot;sub_institute_type&quot;:&quot;Govt.  School&quot;,&quot;sub_institute_type_slug&quot;:&quot;Govt.-School&quot;,&quot;created_at&quot;:&quot;2022-06-16T18:31:16.000000Z&quot;,&quot;updated_at&quot;:&quot;2022-06-16T18:32:39.000000Z&quot;}]</option>-->
                                <optgroup label="College">
                                    <option value="39">Private College</option>
                                    <option value="40">Govt. College</option>
                                </optgroup>
                                <!--<option value="6">[{&quot;id&quot;:39,&quot;institute_type_id&quot;:6,&quot;sub_institute_type&quot;:&quot;Private College&quot;,&quot;sub_institute_type_slug&quot;:&quot;Private-College&quot;,&quot;created_at&quot;:&quot;2022-06-16T18:32:04.000000Z&quot;,&quot;updated_at&quot;:&quot;2022-06-16T18:33:31.000000Z&quot;},{&quot;id&quot;:40,&quot;institute_type_id&quot;:6,&quot;sub_institute_type&quot;:&quot;Govt. College&quot;,&quot;sub_institute_type_slug&quot;:&quot;Govt.-College&quot;,&quot;created_at&quot;:&quot;2022-06-16T18:33:48.000000Z&quot;,&quot;updated_at&quot;:&quot;2022-06-16T18:33:48.000000Z&quot;}]</option>-->
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label text-muted">Select Division</label>
                            <select name="division_id" class="form-select rounded-10px border-2">
                                <option value="12">ঢাকা বিভাগ</option>
                                <option value="10">চট্টগ্রাম বিভাগ</option>
                                <option value="9">রাজশাহী বিভাগ</option>
                                <option value="8">খুলনা বিভাগ</option>
                                <option value="7">বরিশাল বিভাগ</option>
                                <option value="6">সিলেট বিভাগ</option>
                                <option value="5">রংপুর বিভাগ</option>
                                <option value="4">ময়মনসিংহ বিভাগ</option>
                            </select>
                        </div>

                        <div class="col-12">
                            <label class="form-label text-muted">Select Board</label>
                            <select name="board_id" class="form-select rounded-10px border-2">
                                <option value="21">ঢাকা শিক্ষা বোর্ড / Dhaka Education Board</option>
                                <option value="19">চট্টগ্রাম শিক্ষা বোর্ড / Chittagong Edu. Board</option>
                                <option value="18">রাজশাহী শিক্ষা বোর্ড / Rajshahi Education Board</option>
                                <option value="17">বরিশাল শিক্ষা বোর্ড / Barishal Edu. Board</option>
                                <option value="16">কুমিল্লা শিক্ষা বোর্ড/Cumilla Education Board</option>
                                <option value="15">যশোর শিক্ষা বোর্ড / Joshore Education Board</option>
                                <option value="14">ময়মনসিংহ শিক্ষা বোর্ড / Mymensingh Edu. Board</option>
                                <option value="13">সিলেট শিক্ষা বোর্ড / Sylhet Education Board</option>
                                <option value="12">দিনাজপুর শিক্ষা বোর্ড / Dinajpur Education Board</option>
                                <option value="11">মাদ্রাসা শিক্ষা বোর্ড / Madrasah Education Board</option>
                                <option value="10">কারিগরি শিক্ষা বোর্ড / Technical Education Board</option>
                                <option value="9">এডেক্সেল / ক্যামব্রিজ Edexcel / Cambridge of UK</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label text-muted">Location</label>
                            <input type="text" name="location" class="form-control rounded-10px border-2" placeholder="Enter Location">
                        </div>
                        <div class="col-12">
                            <label class="form-label text-muted">Email address</label>
                            <input type="email" name="email" class="form-control rounded-10px border-2" placeholder="Enter Email">
                        </div>
                        <div class="col-12">
                            <label class="form-label text-muted">Password</label>
                            <input type="password" name="password" class="form-control rounded-10px border-2" placeholder="Password">
                        </div>
                        <div class="col-12 d-grid pt-3">
                            <button type="submit" class="btn bg-primary text-white rounded-10px">Create account</button>
                        </div>
                        <div class="col-12 text-center">
                            <div class="py-3 fs-16 fw-500">Or</div>
                            <a class="btn bg-secondary text-white lh-1 px-4" href="#"
                                onclick="hideRecoverPasswordForm();return false;">Login</a>
                        </div>
                    </div>
                </form>

                <script>
                    function showRecoverPasswordForm() {
                        document.getElementById('CreateAccountForm').style.display = 'none';
                        document.getElementById('RecoverPasswordForm').style.display = 'block';
                        document.getElementById('CustomerLoginForm').style.display = 'none';
                    }

                    function hideRecoverPasswordForm() {
                        document.getElementById('CreateAccountForm').style.display = 'none';
                        document.getElementById('RecoverPasswordForm').style.display = 'none';
                        document.getElementById('CustomerLoginForm').style.display = 'block';
                    }

                    function ShowCreateAccountForm() {
                        document.getElementById('CreateAccountForm').style.display = 'block';
                        document.getElementById('CustomerLoginForm').style.display = 'none';
                        document.getElementById('RecoverPasswordForm').style.display = 'none';
                    }

                    // Allow deep linking to the recover password form
                    if (window.location.hash == '#recover') {
                        showRecoverPasswordForm()
                        ShowCreateAccountForm()
                    }

                </script>
            </div>
        </div>
    </div>
</section>

@endsection
