
@extends('backend.layouts.master')

@section('title')
Admin Panel - District Edit
@endsection

@section('styles')
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />

<style>
    .form-check-label {
        text-transform: capitalize;
    }
</style>
@endsection


@section('admin-content')

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">District Edit</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                    <li><a href="{{ route('admin.district.index') }}">All District</a></li>
                    <li><span>Edit District</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            @include('backend.layouts.partials.logout')
        </div>
    </div>
</div>
<!-- page title area end -->

<div class="main-content-inner">
    <div class="row">
        <!-- data table start -->
        <div class="col-8 offset-2 mt-5">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Edit District</h4>
                    @include('backend.layouts.partials.messages')
                    
                    <form action="{{ route('admin.district.update',$district->id) }}" method="POST" enctype="multipart/form-data">
                        @method('PUT')
                        @csrf
                        <div class="form-row">
                            <div class="form-group col-md-12 col-sm-12">
                                <label for="class_name">Select Division</label>
                                <select class="form-control select2" name="division_id" id="">
                                    @foreach(App\Models\Division::orderByDesc('id')->get() as $row)
                                        <option value="{{ $row->id }}" @if($district->division_id == $row->id) selected @endif>{{ $row->division_name ?? '' }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-12 col-sm-12">
                                <label for="district_name">District Name</label>
                                <input type="text" class="form-control" id="district_name" name="district_name" value="{{ $district->district_name ?? '' }} ">
                            </div>
                        </div>
                        <div class="form-row">
                            <span>Old Cover Photo : </span>
                            <img src="{{ asset('public/uploads/'.$district->cover_photo) }}" alt="" width="40" height="30">
                            <div class="form-group col-md-12 col-sm-12">
                                <label for="cover_photo">Cover Photo</label>
                                <input type="file" class="form-control" id="cover_photo" name="cover_photo">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Save District</button>
                    </form>
                </div>
            </div>
        </div>
        <!-- data table end -->
        
    </div>
</div>
@endsection

@section('scripts')
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2();
    })
</script>
@endsection