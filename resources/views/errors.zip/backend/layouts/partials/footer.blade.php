
<!-- footer area start-->
<footer>
    <div class="footer-area">
        <p>© Copyright 2021. All right reserved.</p>
    </div>
</footer>
<!-- footer area end-->